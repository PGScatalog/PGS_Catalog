URLS = {
    'europepmc': 'https://www.ebi.ac.uk/europepmc/webservices/rest/search',
    'ols_efo': 'https://www.ebi.ac.uk/ols/api/ontologies/efo/terms',
    'gwas': 'https://www.ebi.ac.uk/gwas/rest/api/studies'
}
